Проект: Путешествие по России

Описание: Однастраничный сайт о путешествии по России. Проект выполнен по макету Figma. Проект ааптированпод самые распространённые разрешения экранов.

Технологии: - HTML/CSS.
            - Nested БЭМ.
            - CSS анимация.
            - GitHub Pages для хостинга.
            - Grid Layout.
            - Media queries.
Ссылка на проект в GitHub: https://alorlv.github.io/RusTuristo/index.html 